<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    
    <title>coffe_soul</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/> 
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/media.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__nav">
                <a href="index.php" class="header__nav-logo">
                    <img src="./img/header/logo.svg" alt="logo" class="logo__img">
                </a>
                <nav class="nav">
                    <ul class="nav-list">
                        <li class="nav-item">
                            <a href="#section_main" class="nav-link">Главная</a></li>
                        <li class="nav-item">
                            <a href="#section_about_us" class="nav-link">О нас</a></li>
                        <li class="nav-item">
                            <a href="#section_menu" class="nav-link">Меню</a></li>
                        <li class="nav-item">
                            <a href="#section_gallery" class="nav-link">Галерея</a></li>
                        <li class="nav-item">
                            <a href="#section_promo" class="nav-link">Акции</a></li>
                        <li class="nav-item">
                            <a href="#section_coffe_to_go" class="nav-link">Кофе с собой</a></li>
                        <li class="nav-item">
                            <a href="#section_contacts" class="nav-link">Контакты</a></li>
                    </ul>
                </nav>
                <div class="header__adress">
                    <a href="#" class="header__adress-text">г. Ульяновск <br>
                        ул. Северная, 8а</a>
                    <a href="tel:+79008889090" class="header__adress-number">+79008889090</a>
                </div>
                <div class="header__nav__burger_container">
                    <div class="burger">
                        <span class="line line1"></span ><span class="line line2"></span><span class="line line3"></span>
                    </div> 
                </div>
            </div>
        </div>
    </header>   
        <section class="mobile_menu">
            <div class="container">
            <nav class="mobile_menu__nav">
                <ul  class="nav-list">
                    <li class="nav-item">
                        <a href="index.php" href="#section_main" class="nav-link">Главная</a></li>
                    <li class="nav-item">
                        <a href="index.php#section_about_us" class="nav-link">О нас</a></li>
                    <li class="nav-item">
                        <a href="index.php#section_menu" class="nav-link">Меню</a></li>
                    <li class="nav-item">
                        <a href="index.php#section_gallery" class="nav-link">Галерея</a></li>
                    <li class="nav-item">
                        <a href="index.php#section_promo" class="nav-link">Акции</a></li>
                    <li class="nav-item">
                        <a href="index.php#section_coffe_to_go" class="nav-link">Кофе с собой</a></li>
                    <li class="nav-item">
                        <a href="index.php#section_contacts" class="nav-link">Контакты</a></li>
                </ul>
            </nav>
        </div>
        </section>
    <main class="main">
        <div class="container">
            <section id="section_main" class="section_main">
                <div class="section_main-wrapper">
                    <div class="section_main__box">
                        <h1 class="main_title title">Время пить кофе</h1>
                        <a href="index2.php" class="main_btn button">ВЫБРАТЬ</a>
                        <div class="section_main__box-text">
                            <p class="text">
                                Если не начать день с чашечки свежего кофе, то зачем тогда просыпаться.
                                <br>
                                <br>  
                            </p>
                            <span class="text">Иосиф Бродский</span> 
                        </div>  
                    </div>
                    <div class="section_main__box-img">
                        <div class="section_main__box-img_small">
                            <div class="box-img_small__item item1">
                                <img class="img" src="./img/main/section_main/dextop1muhammad-syafi-al-adam-carO6s-ZGOc-unsplash.webp" alt="img1">
                            </div>
                            <div class="box-img_small__item item2">
                                <img class="img" src="./img/main/section_main/dextop2andrew-neel-cckf4TsHAuw-unsplash 1.webp" alt="img2">
                            </div>
                        </div>
                        <div class="section_main__box-img_big">
                            <div class="box-img_big__item">
                                <img class="img" src="./img/main/section_main/dextop3nathan-dumlao-dvuHNTJxIsg-unsplash.webp" alt="img3">
                            </div>
                        </div>     
                </div>    
            </section>
            <section id="section_about_us" class="section_about_us">
                <h2 class="section_about_us__title title">О нас</h2>
                <div class="section_about_us__box">
                    <div class="section_about_us__box-logo_text">
                        <div class="section_about_us__box-logo_img">
                            <a href="#" class="section_about_us-logo">
                                <img src="./img/header/logo.svg" alt="logo" class="logo__img">
                            </a>
                            <div class="box-logo_img__item">
                                <img src="./img/main/section_about_us/img1phil-desforges-fjrl9YBYEL0-unsplash_(1)_1_(2).webp" alt="img" class="img">
                            </div>
                        </div>
                        <div class="section_about_us__box-text">
                            <p class="text">Наша кофейня создана с душой, продумана до мелочей, каждый может это прочувствовать придя к нам.
                                <br>
                                <br>
                                У нас вы сможете насладиться тихой и приятной атмосферой - прийти на завтрак, поработать за ноутбуком, пообщаться с близкими за чашечкой кофе с великолепным запахом и приятным вкусом. </p>
                        </div>
                    </div>
                    <div class="wrapper">
                        <div class="section_about_us__box-img">
                            <div class="section_about_us__box-img_item1">
                                <img src="./img/main/section_about_us/img2chris-lee-70l1tDAI6rM-unsplash_(1).webp" alt="image" class="img">
                            </div>
                            <div class="section_about_us__box-img_item2">
                                <img src="./img/main/section_about_us/img3micheile-dot-com-OLqFXM6-MAQ-unsplash_(1).webp" alt="image" class="img">
                            </div>
                        </div>
                    </div>   
                </div>               
            </section>
            <section id="section_menu" class="section_menu">
                <div class="section_menu__wrapper">
                    <h2 class="section_menu__title title">Меню</h2>
                    <div class="section_menu__box">
                        <div class="section_menu__box-item1">
                            <img src="./img/main/section_menu/menu1.webp" alt="menu1" class="img">
                        </div>
                        <div class="section_menu__box-item2">
                            <img src="./img/main/section_menu/menu2.webp" alt="menu2" class="img">
                        </div>
                    </div>
                    <a href="./img/main/section_menu/menu.pdf" target="_blank" class="menu_btn button">Открыть</a>
                </div>
            </section>
            <section id="section_gallery" class="section_gallery">
                <h2 class="section_gallery__title title">Галерея</h2>
                <div class="swiper">                   
                    <button class="swiper_btn swiper-button-prev">
                        <div class="icon">
                            <svg width="33" height="16" viewBox="0 0 33 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0.292892 7.2929C-0.0976296 7.68342 -0.0976295 8.31659 0.292893 8.70711L6.65686 15.0711C7.04738 15.4616 7.68054 15.4616 8.07107 15.0711C8.46159 14.6805 8.46159 14.0474 8.07107 13.6569L2.41421 8L8.07107 2.34315C8.46159 1.95262 8.46159 1.31946 8.07107 0.928934C7.68054 0.53841 7.04738 0.53841 6.65685 0.928934L0.292892 7.2929ZM33 7L1 7L1 9L33 9L33 7Z" fill="black"/>
                            </svg>
                        </div>
                    </button>
                    <div class="swiper-wrapper">
                    <!-- Slides -->
                        <div class="swiper-slide swiper-card"><div class="card__image">
                            <img class="img" src="img/main/section_gallery/3micheile-dot-com-EOJqV9lZNDk-unsplash.webp" alt="image">
                        </div></div>
                        <div class="swiper-slide swiper-card"><div class="card__image center">
                            <img class="img" src="img/main/section_gallery/1nathan-dumlao-g8gOnhMRckw-unsplash.webp" alt="image">
                        </div></div>
                        <div class="swiper-slide swiper-card"><div class="card__image ">
                            <img class="img" src="img/main/section_gallery/2micheile-dot-com-x4pNX-7PCp4-unsplash.webp" alt="image">
                        </div></div>
                        <div class="swiper-slide swiper-card"><div class="card__image">
                            <img class="img" src="img/main/section_gallery/3micheile-dot-com-EOJqV9lZNDk-unsplash.webp" alt="image">
                        </div></div>
                        <div class="swiper-slide swiper-card"><div class="card__image center">
                            <img class="img" src="img/main/section_gallery/1nathan-dumlao-g8gOnhMRckw-unsplash.webp" alt="image">
                        </div></div>
                        <div class="swiper-slide swiper-card"><div class="card__image ">
                            <img class="img" src="img/main/section_gallery/2micheile-dot-com-x4pNX-7PCp4-unsplash.webp" alt="image">
                        </div></div>
                    </div>                    
                    <button class="swiper_btn swiper-button-next">
                        <div class="icon">
                            <svg width="33" height="16" viewBox="0 0 33 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M32.7071 8.7071C33.0976 8.31658 33.0976 7.68341 32.7071 7.29289L26.3431 0.92893C25.9526 0.538406 25.3195 0.538406 24.9289 0.92893C24.5384 1.31945 24.5384 1.95262 24.9289 2.34314L30.5858 8L24.9289 13.6569C24.5384 14.0474 24.5384 14.6805 24.9289 15.0711C25.3195 15.4616 25.9526 15.4616 26.3431 15.0711L32.7071 8.7071ZM8.74228e-08 9L32 9L32 7L-8.74228e-08 7L8.74228e-08 9Z" fill="black"/>
                            </svg>
                        </div>
                    </button>
                </div>
            </section>
            <section id="section_promo" class="section_promo">
                <h2 class="section_promo__title title">Акции</h2>
                <div class="section_promo__box-1 section_promo__box">
                    <div class="section_promo__box-1__item1">
                        <img src="./img/main/section_promo/img1.webp" alt="image" class="img">
                    </div>
                    <p class="section_promo__text1">
                        Скидка 10% <br> на кофе до 10 часов
                    </p>
                    <div class="section_promo__box-1__item2">
                        <div class="box-1__item2-img1">
                            <img src="./img/main/section_promo/img2.webp" alt="image" class="img">
                        </div>
                        <div class="box-1__item2-img2">
                            <img src="./img/main/section_promo/pawel-czerwinski-lWBZ01XRRoI-unsplash_2.webp" alt="image" class="img">
                        </div>
                    </div>
                </div>
                <div class="section_promo__box-2 section_promo__box">
                    <div class="section_prom__box-2__item1">
                        <img src="./img/main/section_promo/img3.webp" alt="image" class="img">
                    </div>
                    <p class="section_promo__text2">
                        Скидка 20% <br> на десерты после <br> 17 часов
                    </p>
                    <div class="section_prom__box-2__item2">
                        <img src="./img/main/section_promo/img4.webp" alt="image" class="img">
                    </div>

                </div>

            </section>
            <section id="section_coffe_to_go" class="section_coffe_to_go">
                <div class="section_coffe_to_go__box1">
                    <h2 class="section_coffe_to_go__title title">Кофе с собой</h2>
                    <span class="section_coffe_to_go__span">Согрейся дома</span>
                    <a href="index2.php" class="section_coffe_to_go__btn button">ВЫБРАТЬ</a>
                </div>
                <div class="section_coffe_to_go__box2">
                    <div class="section_coffe_to_go__box2__img1">
                        <img class="img" src="./img/main/section_coffe_to_go/img1.webp" alt="image">
                    </div>
                    <div class="section_coffe_to_go__box2__img2">
                        <img class="img" src="./img/main/section_coffe_to_go/img2.webp" alt="image">
                    </div>
                    <div class="section_coffe_to_go__box2__img3">
                        <img class="img" src="./img/main/section_coffe_to_go/img3.webp" alt="image">
                    </div>
                </div> 
            </section>
            <section id="section_contacts" class="section_contacts">
                <div class="section_contacts__wrapper">
                    <div class="section_contacts__box">
                        <div class="section_contacts__box__text_contriner">
                            <h2 class="section_contacts__title title">Контакты</h2>
                            <div class="section_contacts__span_conteiner">
                                <span class="section_contacts__span section_contacts__span1">Адрес: <br>
                                    г. Ульяновск <br>
                                    ул. Северная, 8а</span>
                                <span class="section_contacts__span">Ждем Вас <br>
                                        ежедневно <br> 
                                    с 9:30 до 23:00</span>
                            </div>
                        </div>
                        <div class="section_contacts__box__img1">
                            <img src="./img/main/section_contacts/img1.webp" alt="image" class="img">
                        </div>
                        <div class="section_contacts__box__img2">
                            <img src="./img/main/section_contacts/img2.webp" alt="image" class="img">
                        </div>
                    </div> 
                </div>   
            </section>
        </div>   
    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer__wrapper">
                <a href="#" class="footer__logo">
                    <img src="./img/footer/logo.svg" alt="logo" class="logo__img">
                </a>
                <span class="footer__span">Политика конфиденциальности</span>
                <div class="footer__box">
                    <div class="footer__social">
                        <a href="#" class="telegram social">
                            <img src="./img/footer/telegram.svg" alt="telegram" class="img">
                        </a>
                        <a href="#" class="vk social">
                            <img src="./img/footer/vk.svg" alt="vk" class="img">
                        </a>
                    </div>
                    <a href="tel:+79008889090" class="footer__number">+79008889090</a>
                </div>
            </div>    
        </div>
    </footer>

    <script src="./js/main.js"></script>
    <script src="./js/swiper.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    
</body>
</html>