<?php
const SITE_ROOT = __DIR__;
const BASE_URL = "http://localhost/coffe_soul/";
define("ROOT_PATH", realpath(dirname(__FILE__)));