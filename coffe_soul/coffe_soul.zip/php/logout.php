<?php

session_start();

unset($_SESSION['id']); 
unset($_SESSION['name']);
unset($_SESSION['phone']); 
unset($_SESSION['adress']); 
header('location: ../index2.php');