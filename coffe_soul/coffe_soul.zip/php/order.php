<?php
$orderInfo = json_decode($_POST['arr']);

$mysql = new mysqli('localhost','root','','register');
session_start();
$usersID = $_SESSION['id'];

// Добавляю Заказ (номер, сумму, idпользователя, время)

$sumProducts = array_pop($orderInfo);


$sumPrice = $sumProducts->sumPrice;
$sumPriceDate = $sumProducts->date;


$mysql ->query("INSERT INTO `orders` (`usersID`, `sumPrice`, `date`) VALUES('$usersID', '$sumPrice', '$sumPriceDate')");
$mysql->error;

$result = $mysql->query("SELECT * FROM `orders` WHERE `date` = '$sumPriceDate'");
$orders = $result->fetch_assoc();
$idorders = $orders['idorders'];





for ($i=0; $i<count($orderInfo); $i++) {
    
    $id = $orderInfo[$i]->id;
    $title = $orderInfo[$i]->title;
    $weight = $orderInfo[$i]->weight;
    $price = $orderInfo[$i]->price;
    $counter = $orderInfo[$i]->counter;
    $date = $orderInfo[$i]->date;
  
    $mysql ->query("INSERT INTO `products` (`idorders`, `usersID`, `id`, `title`, `weight`, `price`, `counter`, `date`) VALUES ('$idorders', '$usersID', '$id', '$title', '$weight', '$price', '$counter', '$date')");   
    $mysql->error; 

 }
 $mysql ->close();





