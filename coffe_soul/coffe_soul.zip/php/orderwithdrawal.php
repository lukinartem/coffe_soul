<?php
session_start();
$usersID = $_SESSION['id'];
$mysql = new mysqli('localhost','root','','register');



$result = $mysql->query("SELECT * FROM `orders` WHERE `usersID` = $usersID ");


$orders = array();

while($row = $result->fetch_assoc()) {
    $orders[]=$row;  
}
$products = array();
function renderProducts ($idorders) {
    
    global $mysql;
    global $usersID;
    global $products;
    global $row;
    global $resultProducts;
    $resultProducts =  $mysql->query("SELECT * FROM `products` WHERE `usersID` = $usersID AND `idorders` = $idorders");
    
    while($row = $resultProducts->fetch_assoc()) {
        $products[]=$row;  
    }
}


